import React, { useState } from "react";
import ImageUpload from "./components/ImageUpload";
import ImageGallery from "./components/ImageGallery";

function App() {
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  const handleImageUpload = () => {
    // Increment trigger to force ImageGallery refresh
    setRefreshTrigger((prev) => prev + 1);
  };

  return (
    <div className="App">
      <main className="app-main">
        <div className="container">
          <section className="upload-section">
            <ImageUpload onImageUpload={handleImageUpload} />
          </section>

          <section className="gallery-section">
            {<ImageGallery key={refreshTrigger} />}
          </section>
        </div>
      </main>
    </div>
  );
}

export default App;
