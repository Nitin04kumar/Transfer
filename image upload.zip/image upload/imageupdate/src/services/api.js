import axios from "axios";

const API_BASE_URL = "http://localhost:8080/api";

// Create axios instance with default config
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
  timeout: 30000,
  withCredentials: false,
});

// Add request interceptor
api.interceptors.request.use(
  (config) => {
    console.log(
      `Making ${config.method?.toUpperCase()} request to: ${config.url}`
    );
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error("API Error:", error);

    let errorMessage = "An unexpected error occurred";

    if (error.code === "ERR_NETWORK") {
      errorMessage =
        "Unable to connect to server. Please check if the backend is running.";
    } else if (error.response) {
      // Server responded with error status
      errorMessage =
        error.response.data?.message ||
        error.response.data ||
        `Server error: ${error.response.status}`;
    } else if (error.request) {
      errorMessage =
        "No response received from server. Please check your connection.";
    } else {
      errorMessage = error.message;
    }

    const enhancedError = new Error(errorMessage);
    enhancedError.status = error.response?.status;
    enhancedError.data = error.response?.data;

    return Promise.reject(enhancedError);
  }
);

export const imageAPI = {
  // Upload image
  uploadImage: async (file, name) => {
    const formData = new FormData();
    formData.append("file", file);
    formData.append("name", name);

    return api.post("/images/upload", formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
      timeout: 60000,
    });
  },

  // Get single image details by ID
  getImageDetails: async (id) => {
    return api.get(`/images/details/${id}`);
  },

  // Get image URL
  getImageUrl: (id) => `${API_BASE_URL}/images/${id}`,

  // Delete image
  deleteImage: async (id) => {
    return api.delete(`/images/${id}`);
  },
};

export default api;
