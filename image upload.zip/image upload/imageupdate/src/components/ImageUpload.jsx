import React, { useState } from "react";
import { imageAPI } from "../services/api";

const ImageUpload = ({ onImageUpload }) => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");
  const [previewUrl, setPreviewUrl] = useState("");

  const handleFileSelect = (event) => {
    const file = event.target.files[0];

    if (file) {
      // Validate file type
      if (!file.type.startsWith("image/")) {
        setError("Please select an image file (JPEG, PNG, GIF, etc.)");
        setSelectedFile(null);
        setPreviewUrl("");
        return;
      }

      // Validate file size (5MB max)
      if (file.size > 5 * 1024 * 1024) {
        setError("File size must be less than 5MB");
        setSelectedFile(null);
        setPreviewUrl("");
        return;
      }

      setSelectedFile(file);
      setError("");

      reader.readAsDataURL(file);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      setError("Please select a file");
      return;
    }

    setUploading(true);
    setError("");

    try {
      // Use the original filename as the name
      await imageAPI.uploadImage(selectedFile, selectedFile.name);

      // Reset form
      setSelectedFile(null);
      setPreviewUrl("");
      document.getElementById("file-input").value = "";

      // Notify parent component
      if (onImageUpload) {
        onImageUpload();
      }

      alert("Image uploaded successfully!");
    } catch (error) {
      console.error("Upload failed:", error);
      setError(
        error.response?.data?.message ||
          error.message ||
          "Upload failed. Please try again."
      );
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="image-upload-container">
      <h3>Upload Image</h3>

      {/* Drag and Drop Area */}
      <div>
        <input
          id="file-input"
          type="file"
          accept="image/*"
          onChange={handleFileSelect}
          className="file-input"
        />
      </div>

      {/* Upload Button */}
      <button
        onClick={handleUpload}
        disabled={uploading || !selectedFile}
        className={`upload-button ${uploading ? "uploading" : ""}`}
      >
        {uploading ? (
          <>
            <div className="spinner"></div>
            Uploading...
          </>
        ) : (
          "Upload Image"
        )}
      </button>
    </div>
  );
};

export default ImageUpload;
