import React, { useState, useEffect } from "react";
import { imageAPI } from "../services/api";

const ImageGallery = () => {
  const [images, setImages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [searchId, setSearchId] = useState("");
  const [searchMode, setSearchMode] = useState(false);

  // Since we don't have getAllImages, we'll start with empty gallery
  // Images will only be shown when searched by ID
  const fetchImageById = async (id) => {
    if (!id.trim()) {
      setError("Please enter an image ID");
      return;
    }

    try {
      setLoading(true);
      setError("");

      // Since your backend only returns the image binary data (not JSON),
      // we can't get image details. We'll just create a mock image object
      // for display purposes
      const imageObject = {
        id: id,
        name: `Image ${id}`,
        // Add other properties you might need
      };

      setImages([imageObject]);
      setSearchMode(true);
    } catch (error) {
      console.error("Error fetching image:", error);
      setError(
        error.response?.data?.message ||
          error.message ||
          "Image not found or error loading image."
      );
      setImages([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    fetchImageById(searchId);
  };

  const handleClearSearch = () => {
    setSearchId("");
    setSearchMode(false);
    setImages([]); // Clear images since we can't fetch all
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
      handleSearch();
    }
  };

  useEffect(() => {
    // No initial fetch since we don't have getAllImages
    setLoading(false);
  }, []);

  if (loading) {
    return (
      <div className="gallery-loading">
        <div className="spinner large"></div>
        <p>Loading images...</p>
      </div>
    );
  }

  return (
    <div className="image-gallery">
      {/* Search Header */}
      <div className="search-header">
        <div className="search-controls">
          <div className="search-input-group">
            <input
              type="text"
              placeholder="Enter Image ID..."
              value={searchId}
              onChange={(e) => setSearchId(e.target.value)}
              onKeyPress={handleKeyPress}
              className="search-input"
            />
            <button
              onClick={handleSearch}
              disabled={!searchId.trim()}
              className="search-button"
            >
              Search by ID
            </button>
          </div>

          {searchMode && (
            <button onClick={handleClearSearch} className="clear-search-button">
              Clear Search
            </button>
          )}
        </div>

        {searchMode && images.length > 0 && (
          <div className="search-info">Showing image ID: {images[0].id}</div>
        )}
      </div>

      {/* Error Display */}
      {error && <div className="error-message">{error}</div>}

      {/* Images Display */}
      {images.length > 0 ? (
        <div className="gallery-grid">
          {images.map((image) => (
            <div key={image.id} className="image-card">
              <div className="image-container">
                <img
                  src={imageAPI.getImageUrl(image.id)}
                  alt={image.name}
                  className="gallery-image"
                  onError={(e) => {
                    e.target.src =
                      "https://via.placeholder.com/300x200/cccccc/969696?text=Image+Not+Found";
                  }}
                  loading="lazy"
                />
                <div className="image-info">
                  <div className="image-name">{image.name}</div>
                  <div className="image-id">ID: {image.id}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        !searchMode &&
        !loading && (
          <div className="empty-state">
            <p>Enter an Image ID to search for images</p>
          </div>
        )
      )}
    </div>
  );
};

export default ImageGallery;
